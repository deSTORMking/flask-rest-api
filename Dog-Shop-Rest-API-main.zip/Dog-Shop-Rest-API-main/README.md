# Dog-Shop-Rest-API
created a rest-API for a dog shop with authentication required for editing and deleting dog info
